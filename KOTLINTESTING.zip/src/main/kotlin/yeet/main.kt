package yeet

import org.koin.core.context.startKoin
import org.koin.dsl.module
import yeet.dsl.*

fun main(args : Array<String>) {
    val myModule = module {
        single {
            getCommandManager()
        }
        single { MessageListener(get()) }
        single { Config(System.getenv("BOT_TOKEN"))}
    }

    startKoin {
        modules(myModule)
    }

    val jda = JDA()
    jda.start()
}

fun testCommandHandler(ctx : CommandContext) {
    ctx.reply("test func command handler")
}

fun getCommandManager() : CommandManager {
    return commandManager {
        module(Module.CORE) {
            lambdaCommand("test") {
                description = "A test command"
                exec = { ctx ->
                    ctx.reply("Message from command :^)")
                }
            }

            command("yeet") {
                description = "Yeets things"
                handler { ::testCommandHandler }
            }

            classCommand { HelpCommand() }
        }
        module(Module.MUSIC) {
            lambdaCommand("play") {
                description = "Plays Music"
                exec = { ctx ->
                    ctx.reply("I can't play music but here are the args.")
                    ctx.reply("`[" + ctx.args.joinToString(", ") + "]`")
                }
            }
        }
    }
}
