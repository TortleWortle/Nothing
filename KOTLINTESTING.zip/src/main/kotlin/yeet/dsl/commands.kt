package yeet.dsl

import yeet.CommandContext

class HelpCommand : ICommandCore {
    override fun onCommand(ctx: CommandContext) {
        ctx.reply(
            String.format("```\n%s```",
                ctx.cmdManager.commands.map {
                    it.key + " | " + it.description
                }.joinToString("\n")
            )
        )
    }

    override fun description(): String {
        return "Shows help"
    }

    override fun command(): String {
        return "help"
    }
}

