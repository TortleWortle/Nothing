package yeet

import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent
import yeet.dsl.Command

class CommandManager(val commands: ArrayList<Command>) {
    fun handleCommand(rawMsg : String, event : GuildMessageReceivedEvent) {
        for (cmd in commands.iterator()) {
            if (rawMsg.split(" ")[0] != cmd.key) continue
            cmd.exec(CommandContext(event))
            break
        }
    }
}