package yeet

class FuckThisException : Exception()

fun splitContent(msg : String) : Array<String> {
    val ret = ArrayList<String>()
    try {
        var inString = false
        var buffer = ""
        msg.split(" ").filter { it != "" }.fold(ret) { acc, s ->
            if (!inString) {
                if (s.startsWith("\"")) {
                    buffer += s.substring(1)
                    inString = true
                } else {
                    acc.add(s)
                }
            } else {
                buffer += " "
                if (s.endsWith("\"") && !s.endsWith("\\\"")) {
                    buffer += s.substring(0, s.length - 1)
                    acc.add(buffer)
                    buffer = ""
                    inString = false
                } else {
                    buffer += s
                }
            }
            acc
        }
        if (buffer != "") {
            throw FuckThisException()
        }
    } catch (e : FuckThisException) {
        return msg.split(" ").toTypedArray()
    }

    return ret.toTypedArray()
}
