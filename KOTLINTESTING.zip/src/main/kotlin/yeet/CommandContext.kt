package yeet

import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent
import org.koin.core.KoinComponent
import org.koin.core.get

class CommandContext(val event : GuildMessageReceivedEvent) : KoinComponent {
    val args : Array<String> = splitContent(event.message.contentRaw)
    val cmdManager : CommandManager = get()
    fun reply(msg : String) {
        event.channel.sendMessage(msg).queue()
    }
}