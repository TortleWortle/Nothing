package yeet

data class Config(val token: String)